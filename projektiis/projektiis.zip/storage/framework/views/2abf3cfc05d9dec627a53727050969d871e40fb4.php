

<?php $__env->startSection('navbar'); ?>
  <li><a href="<?php echo e(url('users')); ?>">Users</a></li>
  <li><a href="<?php echo e(url('courses')); ?>">Courses</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class=" col-md-6 col-lg-6">
  <div class="panel panel-primary">
    <div class="panel-heading">Admin</div>
    <div class="panel-body">
     <ul class="list-group">
    	<strong>Name:</strong> <?php echo e(Auth::user()->name); ?>

    	<br>
    	<strong>Username:</strong> <?php echo e(Auth::user()->username); ?>

     </ul>

    </div>      
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>