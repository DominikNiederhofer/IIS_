

<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
  <div class="panel panel-primary">
    <div class="panel-heading"><?php echo e($course->name); ?></div>
    <div class="panel-body">
     <ul class="list-group">
      <?php if(count($course->exams()->get()) == 0): ?>
        <span>no exams, tell your teacher to create some</span>
      <?php else: ?>
        
        <table class="table list-group">
          <tbody>
            <tr>
              <th>Description</th>
              <th>Points</th>
              <th colspan="2">Registration</th>
              <th></th>

            </tr>
              <?php $__currentLoopData = $course->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div>
                  <tr><td colspan="6" class="danger"><?php echo e($exam->type); ?> test</td></tr>
                  <?php $__currentLoopData = $exam->terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($term->term); ?></td>
                      <td>0</td>
                      <td><?php echo e($term->registration()); ?></td>
                                          
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php endif; ?>
      </ul>

    </div>      
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>