

<?php $__env->startSection('navbar'); ?>
  <?php if(Auth::user()->hasRole('admin')): ?>
    <li><a href="<?php echo e(url('users')); ?>">Users</a></li>
    <li><a href="<?php echo e(url('courses')); ?>">Courses</a></li>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class=" col-md-6 col-lg-6">
  <div class="panel panel-primary">
    <div class="panel-heading">User Information</div>
	    <div class="panel-body">
	     <ul class="list-group">
	    	<strong>Name:</strong> <?php echo e($user->name); ?>

            <br>
            <strong>Surname:</strong> <?php echo e($user->surname); ?>

            <br>
            <strong>Email:</strong> <?php echo e($user->email); ?>

            <br>
            <strong>Username:</strong> <?php echo e($user->username); ?>

            <br>
            <?php if($user->degree != null): ?>
              <strong>Degree:</strong> <?php echo e($user->degree); ?>

            <?php endif; ?>
            <br>
            <?php if($user->degree_programme != null): ?>
                <strong>Degree programme:</strong> <?php echo e($user->degree_programme); ?>

            <?php endif; ?>
            <br>
            <?php if($user->study_year != null): ?>
                <strong>University year:</strong> <?php echo e($user->study_year); ?>

            <?php endif; ?>
	     </ul>
    	</div> 
    	
		    	<?php if($user->hasRole('student') || $user->hasRole('teacher')): ?>
	        <div class="panel-heading">Courses</div>
		    <div class="panel-body">
			    <div class="table-responsive">
		        <table class="table table-hover">
		          <thead>
		            <tr>
		              <th scope="col">Course</th>
		              <th scope="col">Shortcut</th>
		              <th scope="col">Type</th>
		              <th scope="col">Credit</th>
		              <th scope="col"></th>
		            </tr>
		          </thead>
		          <tbody>
		            <?php $__currentLoopData = $user->courses()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		              <tr>
		                <td><?php echo e($course->name); ?></td>
		                <td><?php echo e($course->shortcut); ?></td>
		                <td><?php echo e($course->type); ?></td>
		                <td><?php echo e($course->credits); ?></td>
		                <td><form class="form-horizontal" method="post" action="<?php echo e(route('course_user_destroy', [$user->id, $course->id])); ?>"><?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?><button type="submit" class="btn btn-primary">Delete</button></form></td>
		              </tr>
		              <script type="text/javascript">
		                  function del(course, user ){
		                    window.location.href="<?php echo e(url('users')); ?>/"+course+"/"+user;
		                  }
		              </script>   
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		          </tbody>
		        </table>
		    	</div>

		    	<br>
			    <button type="button" class="btn btn-primary " onclick="add_course(<?php echo e($user->id); ?>)">Add course</button>
			    <?php endif; ?>
			    <br>
	  		</div>

	  		


    </div>
</div>
  		
<script type="text/javascript">
  	function add_course(id){
  		window.location.href="<?php echo e(url('users')); ?>/"+id+"/add";
  	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>