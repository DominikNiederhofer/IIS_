

<?php $__env->startSection('content'); ?>
<div class=" col-md-6 col-lg-6">
  <div class="panel panel-primary">
    <div class="panel-heading">Results</div>
    <div class="panel-body">
      <table class="table list-group">
        <body>
          <tr>
            <th>Points</th>
            <th>Comment</th>
            <th>Insert</th>
            <th>Date</th>
          </tr>
          <tr>
            <td><?php echo e($evaluation->points); ?></td>
            <td><?php echo e($evaluation->comment); ?></td>
            <td><?php echo e($evaluation->getTeacher()->username); ?></td>
            <td><?php echo e($evaluation->updated_at); ?></td>
          </tr>
        </body>

      </table>
    </div>      
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>