

<?php $__env->startSection('navbar'); ?>
  <?php if(Auth::user()->hasRole('admin')): ?>
    <li><a href="<?php echo e(url('users')); ?>">Users</a></li>
    <li><a href="<?php echo e(url('courses')); ?>">Courses</a></li>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <?php if(Auth::user()->hasRole('admin')): ?>
        <a href=<?php echo e(url('users/create')); ?>><button type="button" class="btn btn-primary">Create new user</button></a>
      <?php endif; ?>

    <?php $__currentLoopData = ['admin',  'teacher', 'student']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($role == 'admin'): ?>
          <h2>Admins</h2>
      <?php elseif($role == 'teacher'): ?>
          <h2>Teachers</h2>
      <?php elseif($role == 'student'): ?>
          <h2>Students</h2>
      <?php endif; ?>
      <hr>
      <table class="table table-striped table-hover table-bordered table-hover">
        <thead>
          <tr>
            <th>Name</th>
            <th>Surname</th>
            <th>Username</th>
        <?php if($role =='student'): ?>
            <th>Programme</th>
            <th>Year</th>
        <?php endif; ?>
            <th>Edit user</th>
        <?php if($role != 'admin'): ?>
            <th>Delete user</th>
        <?php endif; ?>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($person->hasRole($role)): ?>
             <tr>
                 <td><a href="users/<?php echo e($person->id); ?>"><?php echo e($person->name); ?></a></td>
                    <td><?php echo e($person->surname); ?></td>
                    <td><?php echo e($person->username); ?></td>
                <?php if($person->hasRole('student')): ?>
                    <td><?php echo e($person->degree_programme); ?></td>
                    <td><?php echo e($person->study_year); ?></td>
                <?php endif; ?>
              
                    
                    <td><button type="button" class="btn btn-info" onclick="edit(<?php echo e($person->id); ?>)">Edit</button></td>
                <?php if(!$person->hasRole('admin')): ?>    
                    <td><button type="button" class="btn btn-danger" onclick="del_user(<?php echo e($person->id); ?>)">Delete</button></td>
                <?php endif; ?>
             </tr>
          <?php endif; ?>
          <script type="text/javascript">
                  function del_user(id){
                    window.location.href="<?php echo e(url('delete_user')); ?>/"+id;
                  }
                  function edit(id){
                    window.location.href="<?php echo e(url('edit_user')); ?>/"+id;
                  }
          </script>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <br>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>