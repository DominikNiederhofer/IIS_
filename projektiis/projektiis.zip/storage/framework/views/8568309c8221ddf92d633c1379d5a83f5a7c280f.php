

<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
  <div class="panel panel-primary">
    <div class="panel-heading"><?php echo e($course->name); ?></div>
    <div class="panel-body">
     <ul class="list-group">  
        <table class="table list-group">
          <tbody>
            <tr>
              <th>Description</th>
              <th>Max points</th>
              <th>Max students</th>
              <th colspan="2">Registration</th>
              <th>
                <?php if(Auth::user()->hasRole('teacher')): ?>
                    <form class="form-horizontal" method="get" action="<?php echo e(route('exams_create', $course->id)); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">Create exam</button></form>
                <?php endif; ?>
              </th>

            </tr>
              <?php $__currentLoopData = $course->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div>
                  <tr><td colspan="4" class="h3"><?php echo e($exam->type); ?> test</td>
                    <?php if(Auth::user()->hasRole('teacher')): ?>
                      <td><form class="form-horizontal danger" method="get" action="<?php echo e(route('terms_create', [$exam->id, $course->id])); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">Create term</button></form>
                      </td>
                      <td><form class="form-horizontal danger" method="post" action="<?php echo e(route('exams_destroy', $exam)); ?>"><?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?><button type="submit" class="btn btn-primary">Delete</button></form>
                      </td>
                    <?php endif; ?>
                  </tr>
                  <?php $__currentLoopData = $exam->terms()->orderBy('term')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($term->term); ?></td>
                      <td><?php echo e($exam->max_points); ?></td>
                      <td><?php echo e(count($term->users()->get())); ?>/<?php echo e($exam->max_students); ?></td>
                      <td><?php echo e($term->registration()); ?></td>
                      <?php if(Auth::user()->hasRole('student')): ?>
                        <td>
                          <?php if($term->isregistrated(Auth::user())): ?>
                            <div>
                              <?php if($term->isEnded()): ?>
                              <div>
                                <?php if($term->hasValuate(Auth::user())): ?>
                                <form class="form-horizontal" method="get" action="<?php echo e(route('valuate_show', $exam->id)); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">View valuate</button></form>
                                <?php endif; ?>
                                </div>
                              <?php else: ?>
                                <form class="form-horizontal" method="post" action="<?php echo e(route('terms_unregister', [Auth::user(), $term->id])); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">UnRegister</button></form>
                              <?php endif; ?>
                            </div>
                          <?php else: ?>
                            <div>
                              <?php if(!$term->isEnded()): ?>
                                <form class="form-horizontal" method="post" action="<?php echo e(route('terms_register', [$exam->id, $term->id])); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">Register</button></form>
                              <?php endif; ?>
                            </div>
                          <?php endif; ?>
                        </td> 
                      <?php elseif(Auth::user()->hasRole('teacher')): ?>
                         <td><form class="form-horizontal" method="get" action="<?php echo e(route('terms_valuate', $term->id)); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">Rate students</button></form></td>
                         <td><form class="form-horizontal" method="post" action="<?php echo e(route('terms_destroy', $term->id)); ?>"><?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?><button type="submit" class="btn btn-primary">Delete</button></form></td>
                      <?php endif; ?>                  
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </ul>

    </div>      
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>