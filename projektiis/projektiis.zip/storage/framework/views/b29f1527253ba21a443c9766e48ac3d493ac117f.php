

<?php $__env->startSection('content'); ?>
<div class=" col-md-6 col-lg-6">
  <div class="panel panel-primary">
    <div class="panel-heading">Evaluations</div>
    <div class="panel-body">
     	<table class="table list-group">
     		<body class="col-md-12">
     			<tr>
     				<th>Username</th>
     				<th>Name</th>
     				<th>Email</th>
     				<th></th>
            <th></th>
     			</tr>
		      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      	<tr>
		      		<td><?php echo e($user->username); ?></td>
		      		<td><?php echo e($user->name); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td></td>
              <td>
                <div>
                  <?php if($term->hasValuate($user)): ?>
                    <form class="form-horizontal" method="get" action="<?php echo e(route('valuate_edit', $term->id)); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">edit</button></form></td>
                  <?php else: ?>
                    <form class="form-horizontal" method="get" action="<?php echo e(route('valuate_create', [$user->id, $term->id])); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">open</button></form></td>
                  <?php endif; ?>
                </div>
		      	</tr>
		      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      		</body>
      	</table>
 

    </div>      
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>