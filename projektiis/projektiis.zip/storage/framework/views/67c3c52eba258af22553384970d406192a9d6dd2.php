

<?php $__env->startSection('navbar'); ?>
  <?php if(Auth::user()->hasRole('admin')): ?>
    <li><a href="<?php echo e(url('users')); ?>">Users</a></li>
    <li><a href="<?php echo e(url('courses')); ?>">Courses</a></li>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class=" col-md-6 col-lg-6">
  <div class="panel panel-primary">
    <div class="panel-heading">Courses</div>
    <div class="panel-body">
      <?php if(Auth::user()->hasRole('admin')): ?>
        <form class="form-horizontal" method="get" action="<?php echo e(route('courses_create')); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-primary">Create course</button></form>   
      <?php endif; ?>
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">Course</th>
              <th scope="col">Shortcut</th>
              <th scope="col">Type</th>
              <th scope="col">Credit</th>
              <th scope="col"></th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><a href="/courses/<?php echo e($course->id); ?>"><?php echo e($course->name); ?></a></td>
                <td><?php echo e($course->shortcut); ?></td>
                <td><?php echo e($course->type); ?></td>
                <td><?php echo e($course->credits); ?></td>
                <?php if(Auth::user()->hasRole('admin')): ?>
                  <td><form class="form-horizontal" method="get" action="<?php echo e(route('courses_edit', $course->id)); ?>"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-info">Edit</button></form></td>
                  <td><form class="form-horizontal" method="post" action="<?php echo e(route('courses_destroy', $course->id)); ?>"><?php echo e(csrf_field()); ?><?php echo e(method_field('DELETE')); ?><button type="submit" class="btn btn-danger">Delete</button></form></td>
                <?php endif; ?>
              </tr>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>      
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>