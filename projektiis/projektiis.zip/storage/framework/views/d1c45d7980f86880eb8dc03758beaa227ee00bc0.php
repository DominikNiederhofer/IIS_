

<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
<div class="panel panel-primary">
	<div class="panel-heading"><?php echo e($user->username); ?></div>
	  <div class="panel-body">
	  	<?php if(count($user->courses) == 0): ?>
	  		<span><?php echo e($user->name); ?> has no registered course</span>
	  	<?php else: ?>
	  		<li class="list-group-item"><span class="col col-xs-1">Abrv</span>
			  		<span class="col-xs-4">Title</span>
			  		<span class="col-xs-offset-2">Students </span>
			  	<span class="badge badge-primary">Rests</span></li>
		  	<?php $__currentLoopData = $user->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  	<li class="list-group-item"><span class="col col-xs-1"><?php echo e($course->shortcut); ?> </span>
			  		<a class="col-xs-4" href="courses/<?php echo e($course->id); ?>"><?php echo e($course->name); ?></a>
			  		<span class="col-xs-offset-2"><?php echo e(count($course->students())); ?> </span>
			  	<span class="badge badge-primary">0</span></li> 
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	     <?php endif; ?>
	  </div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>