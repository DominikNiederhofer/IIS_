

<?php $__env->startSection('navbar'); ?>
  <?php if(Auth::user()->hasRole('admin')): ?>
    <li><a href="<?php echo e(url('users')); ?>">Users</a></li>
    <li><a href="<?php echo e(url('courses')); ?>">Courses</a></li>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
  <br>
  <form method="post" action="<?php echo e(route('course_user_add', $user->id)); ?>">
  <?php echo e(csrf_field()); ?>


  <div class="row">
      <label class="col-sm-2 col-form-label">Course:</label>
      <div class="col-sm-5">
        <div class="form-group">
          <select name="course" class="form-control" onchange="formItems(value ,'dynamic')">
              <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
          </div>
      </div>
  </div>

  <div class="row">
      <div class ="col-sm-2">
        <div class="form-group">
          <button class="btn btn-primary">Add</button>
        </div>
      </div>
  </div>
  <?php if(count($errors)): ?>
    <br><br>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li> <strong><?php echo e($error); ?></strong></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>