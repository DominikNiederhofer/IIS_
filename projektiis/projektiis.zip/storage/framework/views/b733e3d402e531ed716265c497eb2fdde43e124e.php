

<?php $__env->startSection('content'); ?>
<div class=" col-md-6 col-lg-6">
  <div class="panel panel-primary">
    <div class="panel-heading">Insert result</div>
    <div class="panel-body">
    	<form class="form-horizontal" method="post" action="<?php echo e(route('valuate_store', [$user->id, $term->id])); ?>" enctype="multipart/form-data"><?php echo e(csrf_field()); ?>

     	<table class="table list-group">
     		<body>
     			<tr>
     				<th>Points</th>
     				<th>Comment</th>
     			</tr>
     			<tr>
     				<td>
     					<div class="form-group">
     						<input type="integer" name="points" class="form-control" autofocus>
     					</div>
     				</td>
					<td>
						<div class="form-group">
     						<input type="text" name="comment" class="form-control" autofocus>
     					</div>
     				</td>
     			</tr>
     			<tr>
     				<td>
     					<button type="submit" class="btn btn-primary">save</button>
     				</td>
     			</tr>
     		</body>

     	</table>
     	</form>
  
    </div>      

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>